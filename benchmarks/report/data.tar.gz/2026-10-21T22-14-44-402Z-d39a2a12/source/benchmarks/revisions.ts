/** Compare the same client workload across isolated historical source snapshots. */
import assert from "node:assert/strict";
import { mkdir, rm, copyFile } from "node:fs/promises";
import { dirname, join, resolve } from "node:path";
import { cpus, release } from "node:os";
import {
  createRun,
  hashFiles,
  json,
  sourceFiles,
  writeJson,
} from "./harness/artifacts";
import { digest, median, type Timing } from "./harness/measure";
import { integer } from "./config";

const root = resolve(import.meta.dir, "..");
const passes = integer("passes", process.argv[2] ?? 5);
const durationMs = integer("durationMs", process.argv[3] ?? 500);
const labels = [
  "before-split",
  "split-only",
  "dialect-strategies",
  "refactor-complete",
  "working",
];
const revisions = ["69f6817", "bf4eaa7", "5c407f8", "840d92d", "working"];
// Optional saved checkout adds an immutable pre-optimization control.
const baseline = process.argv[4] ? resolve(process.argv[4]) : undefined;
if (baseline) {
  labels.splice(-1, 0, "baseline-snapshot");
  revisions.splice(-1, 0, baseline);
}
const selected = process.env.BENCH_REVISIONS?.split(",");
if (selected) {
  assert.ok(
    selected.length >= 2 &&
      new Set(selected).size === selected.length &&
      selected.every((label) => labels.includes(label)),
    `BENCH_REVISIONS requires at least two distinct labels from: ${labels.join(",")}`,
  );
  for (let index = labels.length - 1; index >= 0; index--) {
    if (!selected.includes(labels[index]!)) {
      labels.splice(index, 1);
      revisions.splice(index, 1);
    }
  }
}
const run = await createRun(join(import.meta.dir, "results/revisions"));
const command = async (args: string[]): Promise<string> => {
  const child = Bun.spawn(args, {
    cwd: root,
    stdout: "pipe",
    stderr: "inherit",
  });
  const output = await new Response(child.stdout).text();
  if (await child.exited) throw new Error(`${args.join(" ")} failed`);
  return output.trim();
};
const sources: {
  label: string;
  revision: string;
  directory: string;
  hash: string;
  files: Record<string, string>;
}[] = [];
type Worker = { sql: Record<string, unknown>; results: Record<string, Timing> };
const results: Record<string, Worker[]> = {};
const manifest = {
  version: 1,
  status: "running",
  startedAt: new Date().toISOString(),
  environment: {
    bun: Bun.version,
    platform: process.platform,
    arch: process.arch,
    cpu: cpus()[0]?.model,
    kernel: release(),
  },
  passes,
  durationMs,
  sources,
  orders: [] as string[][],
  harness: {} as Record<string, string>,
  artifacts: {} as Record<string, string>,
  finishedAt: "",
  error: "",
};
try {
  const runner = join(run.directory, "runner");
  for (const file of [
    "revisions.ts",
    "config.ts",
    "harness/revision-worker.ts",
    "harness/measure.ts",
    "harness/artifacts.ts",
  ]) {
    await mkdir(dirname(join(runner, file)), { recursive: true });
    await copyFile(join(import.meta.dir, file), join(runner, file));
  }
  manifest.harness = await hashFiles(runner);

  for (let index = 0; index < revisions.length; index++) {
    const label = labels[index]!;
    const directory = join(run.directory, label);
    await mkdir(directory);
    let revision = revisions[index]!;
    if (revision === "working" || label === "baseline-snapshot") {
      const checkout = label === "baseline-snapshot" ? baseline! : root;
      const files =
        label === "baseline-snapshot"
          ? await hashFiles(checkout)
          : await sourceFiles(checkout);
      for (const file of Object.keys(files)) {
        await mkdir(dirname(join(directory, file)), { recursive: true });
        await copyFile(join(checkout, file), join(directory, file));
      }
      revision =
        label === "baseline-snapshot"
          ? `snapshot:${baseline}`
          : `${await command(["git", "rev-parse", "HEAD"])}+working-tree`;
    } else {
      revision = await command(["git", "rev-parse", `${revision}^{commit}`]);
      const archive = join(run.directory, `${label}.tar`);
      await command([
        "git",
        "archive",
        "--format=tar",
        `--output=${archive}`,
        revision,
        "packages/runtime/src",
        "packages/kit/src",
        "tsconfig.json",
      ]);
      await command(["tar", "-xf", archive, "-C", directory]);
      await rm(archive);
    }
    const files = await hashFiles(directory);
    assert.ok(files["packages/runtime/src/query/compiler.ts"]);
    sources.push({
      label,
      revision,
      directory,
      hash: digest(json(files)),
      files,
    });
    results[label] = [];
  }
  await writeJson(join(run.directory, "manifest.json"), manifest);
  let expected: Worker["sql"] | undefined;
  for (let pass = 0; pass < passes; pass++) {
    const offset = pass % sources.length;
    const order = [...sources.slice(offset), ...sources.slice(0, offset)];
    manifest.orders.push(order.map((source) => source.label));
    for (const source of order) {
      const file = `${pass}-${source.label}.json`;
      const child = Bun.spawn(
        [
          process.execPath,
          join(runner, "harness/revision-worker.ts"),
          join(source.directory, "packages/runtime/src"),
          String(durationMs),
          join(run.directory, file),
        ],
        {
          cwd: root,
          stdout: "inherit",
          stderr: "inherit",
          env: { ...process.env, SYMMETRIA_COMPILE_LOG: "" },
        },
      );
      const timer = setTimeout(() => child.kill("SIGKILL"), 120000);
      try {
        assert.equal(await child.exited, 0, `worker failed: ${file}`);
      } finally {
        clearTimeout(timer);
      }
      const result: Worker = await Bun.file(join(run.directory, file)).json();
      expected ??= result.sql;
      assert.deepEqual(
        result.sql,
        expected,
        `SQL or parameter order changed: ${source.label}`,
      );
      results[source.label]!.push(result);
      console.log(
        `pass ${pass + 1}/${passes} ${source.label}: nested build+SQL ${(result.results.nestedBuildSQL!.p50Ms * 1000).toFixed(2)} µs; compiler ${(result.results.nestedCompiler!.p50Ms * 1000).toFixed(2)} µs`,
      );
    }
  }
  const summary: Record<
    string,
    Record<string, { medianUs: number; minUs: number; maxUs: number }>
  > = {};
  for (const name of Object.keys(results[labels[0]!]![0]!.results)) {
    summary[name] = {};
    for (const label of labels) {
      const values = results[label]!.map(
        (result) => result.results[name]!.p50Ms * 1000,
      );
      summary[name]![label] = {
        medianUs: median(values),
        minUs: Math.min(...values),
        maxUs: Math.max(...values),
      };
    }
  }
  await writeJson(join(run.directory, "summary.json"), summary);
  const lines = [
    "# Compiler revision comparison",
    "",
    `Run: ${run.id}; ${passes} passes × ${durationMs} ms per case; ${Bun.version}, ${process.platform}/${process.arch}, ${manifest.environment.cpu}.`,
    "",
    "Each revision runs in a fresh process. Order changes between passes. Values are median batch-average µs/op; [min–max] describes pass-to-pass p50 variation. All six SQL texts and parameter arrays match byte-for-byte across revisions. No database or network is measured; point execution uses a stub driver. Compiler-only cases bypass the compiled-plan cache and use a prebuilt AST. Build+SQL creates a new query each time.",
    "",
    `| Case | ${labels.join(" | ")} |`,
    `| --- | ${labels.map(() => "---:").join(" | ")} |`,
  ];
  for (const [name, values] of Object.entries(summary))
    lines.push(
      `| ${name} | ${labels
        .map((label) => {
          const value = values[label]!;
          return `${value.medianUs.toFixed(2)} [${value.minUs.toFixed(2)}–${value.maxUs.toFixed(2)}]`;
        })
        .join(" | ")} |`,
    );
  lines.push(
    "",
    ...sources.map(
      (source) =>
        `- ${source.label}: ${source.revision}; source SHA-256 ${source.hash}`,
    ),
    "",
  );
  await Bun.write(join(run.directory, "REPORT.md"), lines.join("\n"));
  for (const source of sources) {
    assert.deepEqual(
      await hashFiles(source.directory),
      source.files,
      `source changed: ${source.label}`,
    );
  }
  assert.deepEqual(
    await hashFiles(runner),
    manifest.harness,
    "harness changed during run",
  );
  for (const file of [
    "summary.json",
    "REPORT.md",
    ...manifest.orders.flatMap((order, pass) =>
      order.map((label) => `${pass}-${label}.json`),
    ),
  ]) {
    manifest.artifacts[file] = digest(
      await Bun.file(join(run.directory, file)).text(),
    );
  }
  manifest.status = "complete";
  manifest.finishedAt = new Date().toISOString();
  await writeJson(join(run.directory, "manifest.json"), manifest);
  console.log(`Complete: ${run.directory}/REPORT.md`);
} catch (error) {
  manifest.status = "failed";
  manifest.finishedAt = new Date().toISOString();
  manifest.error = String(error);
  await writeJson(join(run.directory, "manifest.json"), manifest);
  throw error;
}
