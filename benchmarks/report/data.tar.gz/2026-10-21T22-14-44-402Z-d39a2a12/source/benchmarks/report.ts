import assert from "node:assert/strict";
import { join } from "node:path";
import { digest, median, timing } from "./harness/measure";
import { LIBRARIES } from "./lib";
import { SCENARIOS, applicable, type Scenario } from "./harness/workload";
import {
  writeJson,
  json,
  type Manifest,
  type WorkerResult,
} from "./harness/artifacts";

export const validateRun = async (
  directory: string,
): Promise<{ manifest: Manifest; runs: WorkerResult[] }> => {
  const manifest: Manifest = await Bun.file(
    join(directory, "manifest.json"),
  ).json();
  assert.equal(manifest.version, 1);
  assert.equal(
    manifest.status,
    "complete",
    "refusing to report an incomplete run",
  );
  assert.ok(
    Number.isSafeInteger(manifest.config.passes) && manifest.config.passes > 0,
  );
  assert.ok(
    manifest.libraries.length > 0 &&
      new Set(manifest.libraries).size === manifest.libraries.length,
  );
  assert.ok(manifest.libraries.every((library) => LIBRARIES.includes(library)));
  assert.equal(manifest.orders.length, manifest.config.passes);
  for (const order of manifest.orders)
    assert.deepEqual([...order].sort(), [...manifest.libraries].sort());
  for (const [file, hash] of Object.entries(manifest.files)) {
    assert.ok(!file.includes("..") && !file.startsWith("/"));
    assert.equal(
      digest(await Bun.file(join(directory, file)).text()),
      hash,
      `artifact changed: ${file}`,
    );
  }
  const runs: WorkerResult[] = [];
  for (const library of manifest.libraries) {
    for (const prefix of ["correctness", "plans"])
      assert.ok(
        manifest.files[`${prefix}-${library}.json`],
        `missing ${prefix} for ${library}`,
      );
    const gate = await Bun.file(
      join(directory, `correctness-${library}.json`),
    ).json();
    assert.equal(gate.library, library);
    assert.ok(gate.assertions >= 25);
    for (let pass = 0; pass < manifest.config.passes; pass++) {
      const file = `pass-${pass}-${library}.json`;
      assert.ok(manifest.files[file], `missing ${file}`);
      const run: WorkerResult = await Bun.file(join(directory, file)).json();
      assert.equal(run.library, library);
      assert.equal(run.pass, pass);
      assert.deepEqual(
        Object.keys(run.results).sort(),
        SCENARIOS.filter((scenario) => applicable(library, scenario)).sort(),
      );
      for (const [scenario, result] of Object.entries(run.results)) {
        const seq = result.sequential;
        assert.ok(
          seq.samplesMs.length > 0 &&
            seq.samplesMs.every((n) => Number.isFinite(n) && n >= 0),
        );
        assert.ok(
          Number.isFinite(seq.opsPerSecond) &&
            seq.opsPerSecond > 0 &&
            seq.elapsedMs > 0,
        );
        assert.equal(
          seq.iterations,
          seq.samplesMs.length * (scenario === "buildNested" ? 100 : 1),
        );
        assert.deepEqual(
          seq,
          timing(
            seq.samplesMs,
            seq.elapsedMs,
            scenario === "buildNested" ? 100 : 1,
          ),
          "timing summaries must match raw samples",
        );
        if (scenario !== "buildNested") {
          assert.ok(
            result.concurrent &&
              result.concurrent.perWorker.length ===
                manifest.config.concurrency,
          );
          assert.ok(
            Number.isFinite(result.concurrent.opsPerSecond) &&
              result.concurrent.opsPerSecond > 0,
          );
          assert.equal(
            result.concurrent.iterations,
            result.concurrent.perWorker.reduce((sum, count) => sum + count, 0),
          );
          assert.equal(
            result.concurrent.opsPerSecond,
            (result.concurrent.iterations * 1000) / result.concurrent.elapsedMs,
          );
          assert.ok(
            result.statementsPerOperation !== null &&
              result.statementsPerOperation >= 1,
          );
        }
      }
      runs.push(run);
    }
  }
  const source = manifest.environment.sourceFiles;
  assert.ok(
    source["packages/runtime/src/index.ts"] && source["benchmarks/bench.ts"],
    "missing measured source",
  );
  assert.equal(manifest.environment.sourceHash, digest(json(source)));
  for (const [file, hash] of Object.entries(source))
    assert.equal(
      manifest.files[`source/${file}`],
      hash,
      `missing source snapshot: ${file}`,
    );
  return { manifest, runs };
};

const descriptions: Record<Scenario, string> = {
  pointLookup:
    "SELECT по первичному ключу; воспроизводимая последовательность ID.",
  listJoin: "20 опубликованных постов с автором; created_at DESC, id DESC.",
  nestedFirst: "50 родителей × до 3 постов × теги; OFFSET 0.",
  nestedMiddle: "Та же форма; OFFSET 1000.",
  nestedDeep: "Та же форма; OFFSET 1900.",
  nestedKeyset: "Та же форма; users.id > 1900.",
  insertOne:
    "INSERT одной строки с RETURNING id; 256 последовательных операций и 64 на каждого из 16 воркеров.",
  insertMany500:
    "INSERT 500 строк без RETURNING; 32 последовательных пакета и 4 на каждого из 16 воркеров. ops/s означает пакеты/s.",
  updateViews:
    "Атомарный views = views + 1 с RETURNING views; 512 последовательных операций и 128 на воркер.",
  buildNested:
    "Синхронное построение запроса и SQL; батчи по 100, без БД и await. Перцентили отражают среднее время операции в батче. Raw исключён: у него нет ORM-компилятора; Prisma не предоставляет эквивалентный публичный API.",
};
export const report = async (directory: string): Promise<void> => {
  const { manifest, runs } = await validateRun(directory);
  const env = manifest.environment;
  const lines = [
    "# Результаты контейнерного бенчмарка",
    "",
    `Прогон \`${manifest.id}\`. ${manifest.config.passes} прохода; медианы по проходам, диапазон min–max для throughput.`,
    "",
    `Bun ${env.bun}, ${env.platform}/${env.arch}; CPU контейнера: ${env.cpu}. Хост: ${env.host?.cpu ?? "не указан"}, ${env.host?.os ?? "не указан"}; VM: ${env.host?.docker?.os ?? "не указана"}. PostgreSQL: ${env.postgres}.`,
    "",
    `Исходники Symmetria из checkout; SHA-256 дерева измеряемых файлов: \`${env.sourceHash}\`.`,
    "",
    `Версии: ${Object.entries(env.versions)
      .map(([name, version]) => `${name} ${version}`)
      .join(", ")}.`,
    "",
    `Cgroup runner: CPU \`${env.cgroup.cpuMax}\`, RAM \`${env.cgroup.memoryMax}\` bytes. Полные сведения о хосте, контейнерах и настройках БД — в manifest.json.`,
    "",
    "Все адаптеры прошли независимый oracle до замеров. Родители и посты сравниваются в исходном порядке; теги — как неупорядоченные коллекции. Bigint проверяется без потери точности, включая значения > 2^53. SQL и EXPLAIN ANALYZE сохранены отдельно от timed-фаз.",
    "",
    `Read-фазы: минимум ${manifest.config.sequentialMs} ms / ${manifest.config.minimumSamples} последовательных samples; ${manifest.config.concurrentMs} ms при concurrency=${manifest.config.concurrency}. Пулы по 16; Prisma использует node-postgres, остальные Bun.SQL. Измеряется полный build/bind/execute/decode, нормализация вне тайминга.`,
    "",
    "Записи имеют фиксированный бюджет; перед каждой измеряемой фазой записи восстанавливается seed. Отчёт показывает p50/p95; p99 приводится только при ≥1000 samples в каждом проходе. SQL/op — разность calls верхнего уровня pg_stat_statements только для этой базы, делённая на число последовательных операций; глобального reset нет.",
    "",
    "Concurrent ops/s — операции приложения, а SQL/op измеряется в последовательной фазе. Prisma может объединять конкурентные unique lookup в SQL-пакеты; количество SQL-запросов в concurrent-фазе здесь отдельно не измеряется. Один p50 не заменяет throughput и распределение задержек.",
    "",
  ];
  const summary: Record<string, unknown> = {};
  const f = (value: number) => value.toFixed(3);
  const count = (value: number) => Math.round(value).toLocaleString("en-US");
  for (const scenario of SCENARIOS) {
    const unit = scenario === "buildNested" ? "µs" : "ms";
    const scale = scenario === "buildNested" ? 1000 : 1;
    lines.push(
      `## ${scenario}`,
      "",
      descriptions[scenario],
      "",
      `| Библиотека | p50, ${unit} | p95, ${unit} | p99, ${unit} | seq ops/s | conc×16 ops/s [min–max] | SQL/op |`,
      "| --- | ---: | ---: | ---: | ---: | ---: | ---: |",
    );
    const rows = [];
    for (const library of manifest.libraries.filter((library) =>
      applicable(library, scenario),
    )) {
      const selected = runs.filter((run) => run.library === library);
      const values = selected.map((run) => run.results[scenario]!);
      const conc = values.flatMap((value) =>
        value.concurrent ? [value.concurrent.opsPerSecond] : [],
      );
      const p99 = values.map((value) => value.sequential.p99Ms);
      const row = {
        library,
        name: selected[0]!.name,
        p50Ms: median(values.map((value) => value.sequential.p50Ms)),
        p95Ms: median(values.map((value) => value.sequential.p95Ms)),
        p99Ms: p99.every((value) => value !== null)
          ? median(p99 as number[])
          : null,
        sequentialOps: median(
          values.map((value) => value.sequential.opsPerSecond),
        ),
        concurrentOps: conc.length ? median(conc) : null,
        concurrentMin: conc.length ? Math.min(...conc) : null,
        concurrentMax: conc.length ? Math.max(...conc) : null,
        statements:
          scenario === "buildNested"
            ? null
            : median(values.map((value) => value.statementsPerOperation!)),
      };
      rows.push(row);
      lines.push(
        `| ${row.name} | ${f(row.p50Ms * scale)} | ${f(row.p95Ms * scale)} | ${row.p99Ms === null ? "—" : f(row.p99Ms * scale)} | ${count(row.sequentialOps)} | ${row.concurrentOps === null ? "—" : `${count(row.concurrentOps)} [${count(row.concurrentMin!)}–${count(row.concurrentMax!)}]`} | ${row.statements === null ? "—" : row.statements.toFixed(2)} |`,
      );
    }
    summary[scenario] = rows;
    lines.push("");
  }
  lines.push(
    "## Границы выводов",
    "",
    "Тёплые запросы, один синтетический набор данных, Linux-контейнеры и ограниченные ресурсы. Это не универсальный рейтинг ORM и не замер cold start, сетевой WAN-задержки или производственной нагрузки. На macOS оба контейнера работают в Docker VM; эта серия не сравнима напрямую со старыми host-macOS результатами. CPU quotas не резервируют ядра. Диапазон min–max не является доверительным интервалом.",
    "",
    "Direct LATERAL и page-first raw различают стоимость SQL-плана и клиента. Prepared Symmetria показана только для OFFSET-сценариев, где действительно используется prepare(). Prisma query выполняет несколько SQL-запросов и может получать больше промежуточных строк. Измеряется нативная форма каждого адаптера; общая форма используется только для проверки корректности.",
    "",
  );
  await Bun.write(join(directory, "REPORT.md"), lines.join("\n"));
  await writeJson(join(directory, "summary.json"), summary);
};
if (import.meta.main) {
  if (!process.argv[2])
    throw new Error("usage: bun report.ts results/<run-id>");
  await report(process.argv[2]);
}
