import assert from "node:assert/strict";
import { join, resolve } from "node:path";
import { compileTiming, timing, type Timing } from "./measure";
import { writeJson } from "./artifacts";
import type {
  SelectPlan,
  MutationPlan,
} from "../../packages/runtime/src/query/state";

/** All runtime imports point at the selected snapshot, including its private compiler. */
const source = resolve(process.argv[2]!);
const duration = Number(process.argv[3]);
const {
  schema,
  table,
  junction,
  int,
  text,
  bigint,
  timestamptz,
}: typeof import("../../packages/runtime/src") = await import(
  join(source, "index.ts")
);
const {
  compileQuery,
}: typeof import("../../packages/runtime/src/query/compiler") = await import(
  join(source, "query/compiler.ts")
);
const { QUERY_PLAN }: typeof import("../../packages/runtime/src/query/state") =
  await import(join(source, "query/state.ts"));

const users = table({
  id: int.auto,
  email: text.unique,
  name: text,
});

const posts = table({
  id: int.auto,
  slug: text.unique,
  title: text,
  author: users.index,
  state: text.default("draft"),
  views: bigint.default(0n),
  createdAt: timestamptz.now,
});

const tags = table({
  id: int.auto,
  label: text.unique,
});

const postTags = junction({
  post: posts.onDelete.cascade,
  tag: tags.onDelete.cascade,
});

const rows = [
  {
    id: 7,
    email: "seven@example.test",
    name: "Seven",
  },
];

const db = schema(
  {
    users,
    posts,
    tags,
    postTags,
  },
  {
    driver: {
      execute: async () => ({ rows, affectedRows: 1 }),
      close: async () => {},
    },
  },
);

const nested = (offset = false) =>
  db.users((user) => ({
    id: user.id,
    name: user.name,
    posts: user.posts((post) => ({
      title: post.title,
      views: post.views,
      tags: post.tags((tag) => ({ label: tag.label })),
      $orderBy: [post.createdAt.descending, post.id.descending],
      $limit: 3,
    })),
    ...(offset ? { $offset: 1900 } : { $where: user.id.above(1900) }),
    $orderBy: user.id.ascending,
    $limit: 50,
  }));

const list = () =>
  db.posts((post) => ({
    id: post.id,
    title: post.title,
    author: post.author.name,
    $where: post.state.is("published"),
    $orderBy: [post.createdAt.descending, post.id.descending],
    $limit: 20,
  }));

const first = db
  .users((user) => ({
    id: user.id,
    name: user.name,
    $where: user.id.above(3),
  }))
  .cte("first");

const second = first((user) => ({
  id: user.id,
  name: user.name,
})).cte("second");

const cte = second((user, { innerJoin }) => {
  innerJoin(first, (other) => other.id.is(user.id));

  return {
    id: user.id,
    name: user.name,
    $where: user.id.below(100),
  };
});

const insertRows = Array.from({ length: 500 }, (_, index) => ({
  slug: `revision-${index}`,
  title: "Post",
  authorId: (index % 2000) + 1,
}));

const insert = () => db.posts.insert(insertRows);

const plans = {
  nested: nested(),
  offset: nested(true),
  list: list(),
  cte,
  insert: insert(),
  point: db.users.byId(7),
};
const sql = Object.fromEntries(
  Object.entries(plans).map(([name, query]) => [name, query.toSQL()]),
);
assert.deepEqual(await db.users.byId(7).one(), rows[0]);

// Bypass the compiled-plan cache deliberately: repeated toSQL() would measure a cache hit.
const compiler = (query: object) => {
  const plan = (query as unknown as Record<symbol, SelectPlan | MutationPlan>)[
    QUERY_PLAN
  ]!;
  assert.ok(plan);

  return () => compileQuery(plan);
};

const cases: Record<string, () => unknown> = {
  nestedBuild: () => nested(),
  nestedBuildSQL: () => nested().toSQL(),
  nestedCompiler: compiler(plans.nested),
  offsetBuildSQL: () => nested(true).toSQL(),
  offsetCompiler: compiler(plans.offset),
  listBuildSQL: () => list().toSQL(),
  cteCompiler: compiler(plans.cte),
  insertBuildSQL500: () => insert().toSQL(),
};

const results: Record<string, Timing> = {};

for (const [name, invoke] of Object.entries(cases)) {
  for (
    let index = 0;
    index < (name === "insertBuildSQL500" ? 200 : 2000);
    index++
  ) {
    invoke();
  }

  results[name] = compileTiming(invoke, duration);
}

for (let index = 0; index < 2000; index++) {
  await db.users.byId(7).one();
}

const samples: number[] = [];
const started = performance.now();

while (performance.now() - started < duration) {
  const began = performance.now();

  for (let index = 0; index < 100; index++) {
    await db.users.byId(7).one();
  }

  samples.push((performance.now() - began) / 100);
}

results.pointExecute = timing(samples, performance.now() - started, 100);
await writeJson(process.argv[4]!, { sql, results });
